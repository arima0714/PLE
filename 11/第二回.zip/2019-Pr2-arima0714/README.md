# 演習2

## 学籍番号: 1500000
## 名前: 電通太郎
## e-mail: hoge@uec.ac.jp

演習2のレポジトリです．

  - `Practice2.ipynb` 演習２のノートです．

  - 演習2-2 `mksnd1.py` に 500 Hz の純音を Wav ファイルとして生成するスクリプトを作成する．解答例の参照は `ans/mksnd0.py` です．

  - 演習2-3 `fft1.py` に `VoiceSample/KyokoSamping.wav` をFFTにより変換し周波数を表示させるスクリプトを作成する．解答例の参照先は `ans/fft0.py` です．


なお，これは演習で 課題ではないので *提出する必要はありません* が，
README.md の学籍番号，名前，e-mail は修正しておいてください．

