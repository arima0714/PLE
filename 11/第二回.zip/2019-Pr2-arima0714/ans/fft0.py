# -*- coding: utf-8 -*-

import numpy as np
import scipy.fftpack as spf
from scipy.io.wavfile import read
import matplotlib.pyplot as plt

fname = 'VoiceSample/KyokoSampling.wav'  # パスの指定を適切に

y = read(fname)

#
# y のデータ形式は以下のようなタプル
# ( サンプリング周波数, データ部 )
# データ部の形式は，
# N x 2 の行列データ(2の部分は左音声と右音声)
# N はサンプル数
#

Fs = y[0]                 # サンプリングレート
delta = 1./Fs             # サンプル間隔([sec])
Nmax = 65536              # FFT のため 2 ベキでサンプルをとる
fdelta = 1./(Nmax*delta)  # 周波数刻み


t = np.arange(Nmax) * delta
f = np.arange(-Nmax/2, Nmax/2) * fdelta

yl = y[1][:Nmax, 0]       # 左音声
Yl = spf.fft(yl)

plt.figure()

plt.subplot(2, 1, 1)
plt.plot(t, yl)
plt.xlim(0, t[-1])
plt.title('Amplitude')
plt.grid()

plt.subplot(2, 1, 2)
plt.semilogy(f, np.abs(spf.fftshift(Yl)))
plt.xlim(f[0], f[-1])
plt.title('Power(Semi log)')
plt.grid()

plt.show()
