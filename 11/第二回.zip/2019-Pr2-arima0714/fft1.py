# -*- coding: utf-8 -*-

import numpy as np
import scipy.fftpack as spf
from scipy.io.wavfile import read
import matplotlib.pyplot as plt

fname = 'VoiceSample/KyokoSampling.wav'  # パスの指定を適切に

y = read(fname)

#
# y のデータ形式は以下のようなタプル
# ( サンプリング周波数, データ部 )
# データ部の形式は，
# N x 2 の行列データ(2の部分は左音声と右音声)
# N はサンプル数
#

