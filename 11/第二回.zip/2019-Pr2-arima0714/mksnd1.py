# -*- coding: utf-8 -*-

import numpy as np
import scipy.fftpack as spf

from scipy.io.wavfile import write
import matplotlib.pylab as plt

# 設定
Fs = 22050.  # サンプリング周波数 22 KHz
Fc = 500.    # 1000Hz(とりあえず)
dur = 5.     # 5 秒くらいのデータを作ってみる
Amp = 1.0    # 振幅 (とりあえず)

# 信号の生成，時間軸は t，信号自体は x へ格納

# 表示確認用

# モノラルでファイルに書き込んでみる
write(fname, int(Fs), x)
