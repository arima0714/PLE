# -*- coding: utf-8 -*-

import numpy as np
from scipy.io.wavfile import write


def GenFreq(Fc, Fs, dur):
    Amp = 1.0  #振幅

    # 信号の生成
    # 時間軸はt, 信号自体はx へ格納
    delta = 1./Fs   # サンプリング間隔
    Nmax = Fs * dur # サンプル点の数

    t = np.arange(Nmax) * delta
    x = Amp*np.sin(2. * np.pi * Fc * t)

    return x


# 以下に GenFreq を用いて "CDEFGAB" の音階を各 dur 秒間
# 生成するスクリプトコードを書く

Fs = 22100.        # サンプリング周波数
Fcs = (262, 294, 330, 349, 392, 440, 494, 523)

dur = 3 # 3秒

C = GenFreq(262, Fs, dur)
D = GenFreq(294, Fs, dur)
E = GenFreq(330, Fs, dur)
F = GenFreq(349, Fs, dur)
G = GenFreq(392, Fs, dur)
A = GenFreq(440, Fs, dur)
B = GenFreq(494, Fs, dur)
C2 = GenFreq(523, Fs, dur)

Generated = np.hstack((C, D))
Generated = np.hstack((Generated, E))
Generated = np.hstack((Generated, F))
Generated = np.hstack((Generated, G))
Generated = np.hstack((Generated, A))
Generated = np.hstack((Generated, B))
Generated = np.hstack((Generated, C2))

# y に音声波形を入れたものとしてファイルを保存
fname = 'MkSnd4Test.wav'
write(fname, int(Fs), Generated)
