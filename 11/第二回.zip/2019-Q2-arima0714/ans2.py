# -*- coding: utf-8 -*-

# library関連
import numpy as np
import scipy.fftpack as spf
from scipy.io.wavfile import write,read
import matplotlib.pylab as plt
from scipy.signal import chirp, spectrogram
from scipy.fftpack import fft


def SpecGram(x):
    # 時系列 x のスペクトログラムを表示する関数
    # 入力された信号xを1024サンプルのブロックに分割
    x0 = np.arange(256)
    for i in range(0,256):
        x0[i] = x[1][i][0]
    x1 = np.arange(256)
    for i in range(256):
        x1[i] = x[1][256+i][0]
    x2 = np.arange(256)
    for i in range(256):
        x2[i] = x[1][256*2+i][0]
    x3 = np.arange(256)
    for i in range(256):
        x3[i] = x[1][256*3+i][0]
    x4 = np.arange(256)
    for i in range(256):
        x4[i] = x[1][256*4+i][0]
    x5 = np.arange(256)
    for i in range(256):
        x5[i] = x[1][256*5+i][0]
    # 分割したすべてに fft をかける
    X0 = fft(x0)
    X1 = fft(x1)
    X2 = fft(x2)
    X3 = fft(x3)
    X4 = fft(x4)
    X5 = fft(x5)
    
    Xp0 = np.abs(X0).reshape(256,1)
    Xp1 = np.abs(X1).reshape(256,1)
    Xp2 = np.abs(X2).reshape(256,1)
    Xp3 = np.abs(X3).reshape(256,1)
    Xp4 = np.abs(X4).reshape(256,1)
    Xp5 = np.abs(X5).reshape(256,1)
    
    XX = np.hstack((Xp0, Xp1, Xp2, Xp3, Xp4, Xp5))
    
    plt.figure()
    plt.imshow(np.log(XX), aspect=0.01)
    
    plt.figure()
    plt.imshow(np.log(XX[:128,:]),aspect=0.01)
    
    plt.show()


# 以下に SpecGram() を用いてスペクトログラムを表示させる
# スクリプトコードを書く

y = read("./KyokoSampling.wav")

# スペクトログラム表示
SpecGram(y)
