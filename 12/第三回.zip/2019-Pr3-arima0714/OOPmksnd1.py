# -*- coding: utf-8 -*-

import numpy as np
from scipy.io.wavfile import write


class SoundObj():
    def __init__(self, Fsample, duration):
        self.Fcs = {'C':262., 'D':294., 'E':330., 'F':349., 'G':392., 'A':440., 'B':494.}
        self.Fs = Fsample
        self.dur = duration
        self.N = int(Fsample * duration)
        self.x = np.zeros(self.N)   # 音信号のデータ用配列
        # 以下適当な初期化コードを実装する

    def setTone(self, code='C'):
        # self.x にデータを生成させるコードを実装する
        pass

    def getSound(self):
        # データ self.x を返すコードを実装する
        pass

    def getLen(self):
        # データ self.x の長さを返すコードを実装する
        pass


# 以下は SoundObj を用いて 'E' の音を作りファイルに保存するスクリプト
Fs = 22100
dur = 1.0  # 音の持続時間は 1 秒

fname = 'OOPmksnd.wav'
s = SoundObj(Fs, dur)
s.setTone('E')

# モノラル
write(fname, Fs, s.getSound())
