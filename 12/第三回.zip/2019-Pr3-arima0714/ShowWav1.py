# -*- coding: utf-8 -*-

import numpy as np
import scipy.fftpack as spf
from scipy.io.wavfile import read
import matplotlib.pyplot as plt


class ShowWav():
    def __init__(self, filename):
        pass


    def plot(self):
        pass


fname = 'VoiceSample/KyokoSampling.wav'
# fname = 'VoiceSample/OOPmksnd.wav'
s = ShowWav(fname)
s.plot()
