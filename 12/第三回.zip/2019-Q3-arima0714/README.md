# Question3: 課題３用のリポジトリ

## 学籍番号: 1710021
## 名前: 有馬海人
## e-mail: a1710021@edu.cc.uec.ac.jp

1. ``README.md`` ファイルの学籍番号，氏名，e-mailを適宜書き換えること

2. 課題3 の答えのスクリプト

   - 課題3-1 の解答→ ``ans1.py`` に WeatherHacks クラスを実装し，テストコードが動くことを確認しなさい．
   - 課題3-2 の解答→ ``ans2.py`` に GenFreq クラスを実装し，テストコードが動くことを確認しなさい．
   
   を記述すること
   
3. ``git add``, ``git commit``, ``git push`` の操作を行い，
   問題がなければ，``pull & request`` を送る．

