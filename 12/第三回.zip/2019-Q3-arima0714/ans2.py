# -*- coding: utf-8 -*-

import numpy as np
from scipy.io.wavfile import write


class GenFreq(object):
    def __init__(self, Fs=44100., dur=1.):
        # 諸々の初期化
        self.Fcs = {'C':262., 'D':294., 'E':330., 'F':349., 'G':392., 'A':440., 'B':494.}
        self.Fs = Fs
        self.dur = dur

        self.Amp = 1.0
        self.delta = 1./Fs
        self.Nmax = Fs * dur
        self.generated = []

    def getSound(self):
        # 波形データ配列を返す
        return self.generated

    def getLen(self):
        # データ配列長を返す
        return self.Nmax

    def addTone(self, code='C'):
        # おとを重ねる
        self.Fc = self.Fcs[code]
        self.t = np.arange(self.Nmax) * self.delta
        self.x = self.Amp * np.sin(2. * np.pi * self.Fc * self.t)
        self.generated = np.hstack((self.generated, self.x))


# ここからテストコード
# ド・ミ・ソの和音(CEG) を作ってみる

Fs = 44100
s = GenFreq(Fs, dur=1.)
s.addTone('C')
s.addTone('E')
s.addTone('G')
N = s.getLen()

# scipy.wav.iofile の write をインポートしておくこと
write('hogehoge.wav', Fs, s.getSound())
